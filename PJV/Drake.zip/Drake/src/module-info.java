module Drake {
    requires javafx.fxml;
    requires javafx.controls;

    opens thedrake.ui;
}