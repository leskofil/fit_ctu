package thedrake.ui;

import thedrake.Move;

public interface TroopViewContext {

    void troopViewSelected(TroopView troopView);


}
